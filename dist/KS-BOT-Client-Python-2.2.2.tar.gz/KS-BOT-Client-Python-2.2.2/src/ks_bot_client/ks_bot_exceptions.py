class LoggingInError(Exception):
  pass